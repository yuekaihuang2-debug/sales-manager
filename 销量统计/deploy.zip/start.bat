@echo off
chcp 65001 >nul
echo ========================================
echo   库存与销量管理系统 - HTTP 服务器
echo ========================================
echo.
echo 正在检查 Node.js...
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo 未找到 Node.js，请先安装 https://nodejs.org/
    pause
    exit /b
)
echo Node.js 已找到
echo.
echo 正在安装依赖（首次需要联网）...
call npm install
echo.
echo 正在启动服务器...
node server.js
pause